#Rage simple account nuker by me
# Don't be a idiot 
don't use this on your own account unless you hate discord
# DISCLAIMER
im not responsable for what you use this for, your actions not mine.
